#include "gameboard/gameboard.hpp"

int main(){
	/*Τhe whole game flow happens in the gamePlay function of the object of gameboard
	So to play the game we create an object of the gameboard, and just call the gamePlay function*/
	gameboard L5R;
	L5R.gamePlay();
	return 0;
}
