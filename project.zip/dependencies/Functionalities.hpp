#pragma once
bool YesOrNo(char a='y', char b='n',std::string message="Please type 'y' for yes and 'n' for no: ");
int Honorcompare(const void * p1, const void * p2);
void ReadInt(int &ret);
int ReadInt();
std::string ReadString();
void PressEnter();
void SetToRed();
void SetToGreen();
void SetToYellow();
void SetToBlue();
void SetToDefault();
